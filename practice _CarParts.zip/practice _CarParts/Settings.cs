﻿namespace practice__CarParts
{
    public class Settings
    {
        public static string ConStr
        {
            get
            {
                return "Server =(local)\\Sqlexpress;database=SaptarsiDB;Trusted_connection=yes;user id=sa;Password=1234";
            }
        }
    }
}
