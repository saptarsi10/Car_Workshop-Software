﻿namespace practice__CarParts.Models
{
    public class Part
    {
        public int PartId { get; set; }

        public string PartName { get; set; }

        public string PartType { get; set; }

        public double PartPrice { get; set; }
    }
}
