﻿using Microsoft.AspNetCore.Mvc;
using practice__CarParts.Models;
using practice__CarParts.Repository;

namespace practice__CarParts.Controllers
{
    public class PartsController : Controller
    {
        PartManager partManager = new PartManager();

        public IActionResult Index()
        {
            var allParts = partManager.GetParts();

            ViewBag.Msg = TempData["Msg"];
            return View(allParts);
        }

        [HttpGet]
        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Create(Part model)
        {
            return View();
        }

        [HttpGet]
        public IActionResult Edit(int id)
        {
            List<Part> allParts = partManager.GetParts();

            Part part = allParts.Find(p => p.PartId == id);


            if (part != null)
            {

                return View(part);
            }
            else
            {
                return Content("Part Not Found");
            }
        }

        [HttpPost]
        public IActionResult Edit(Part model)
        {
            bool status = partManager.UpdatePart(model.PartId, model.PartName, model.PartType, model.PartPrice);

            if (status == true)
            {
                return RedirectToAction("Index");
            }
            else
            {
                return View();
            }
        }


        [HttpGet]
        public IActionResult Delete(int id)
        {
            List<Part> allParts = partManager.GetParts();

            //check the existance of the part
            Part part = allParts.Find(p => p.PartId == id);


            if (part != null)
            {
                //partManager.DeletePart(id);
                //return RedirectToAction("Index");
                return View(part);
            }
            else
            {
                return Content("Part Not Found");
            }


        }

        [HttpPost]
        [ActionName("Delete")]
        public IActionResult DeletePost(int id)
        {
            //partManager.DeleteOrdersWithPartId(id);
             bool status = partManager.DeletePart(id);
            TempData["Msg"] = status == true ? "Record Deleted Successfully" : "Deletion Failed, because references exists";
            return RedirectToAction("Index");
        }





    }
}
