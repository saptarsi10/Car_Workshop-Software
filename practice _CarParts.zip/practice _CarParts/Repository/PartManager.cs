﻿using practice__CarParts.Models;
using System.Data;
using System.Data.SqlClient;

namespace practice__CarParts.Repository
{
    public class PartManager
    {
        public List<Part> GetParts()
        {
            SqlDataAdapter da = new SqlDataAdapter("Select * From Parts", Settings.ConStr);

            DataTable dt = new DataTable();
            da.Fill(dt);

            List<Part> parts = new List<Part>();
            foreach (DataRow dr in dt.Rows)
            {
                Part par = new Part();
                par.PartId = (int)dr["PartId"];
                par.PartName = (string)dr["PartName"];
                par.PartType = (string)dr["PartType"];
                par.PartPrice = (double)dr["PartPrice"];

                parts.Add(par);
            }
             return parts;
        }


        public bool UpdatePart(int partId, string partName, string partType, double partPrice)
        {
            SqlConnection con = new SqlConnection(Settings.ConStr);//Connection String
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandText = "Update Parts Set PartName = @PartName, PartType = @PartType, PartPrice = @PartPrice Where PartId = @PartId";
            cmd.Parameters.AddWithValue("@PartId", partId);
            cmd.Parameters.AddWithValue("@PartName", partName);
            cmd.Parameters.AddWithValue("@PartType", partType);
            cmd.Parameters.AddWithValue("@PartPrice", partPrice);

            con.Open();
            int numberOfRowsEffected = cmd.ExecuteNonQuery();
            con.Close();


            if (numberOfRowsEffected == 1)
                return true;
            else
                return false;
            
        }

        //Delete
        public bool DeletePart(int partId)
        {
            try
            {
                SqlConnection con = new SqlConnection(Settings.ConStr);//Connection String
                SqlCommand cmd = con.CreateCommand();
                cmd.CommandText = "Delete From Parts Where PartId = @PartId";
                cmd.Parameters.AddWithValue("@PartId", partId);


                con.Open();
                int numberOfRowsEffected = cmd.ExecuteNonQuery();
                con.Close();


                if (numberOfRowsEffected == 1)
                    return true;
                else
                    return false;
            }
            catch
            {
                return false;
            }

        }



        public bool DeleteOrdersWithPartId(int partId)
        {
            try
            {
                SqlConnection con = new SqlConnection(Settings.ConStr);//Connection String
                SqlCommand cmd = con.CreateCommand();
                cmd.CommandText = "Delete From Orders Where PartId = @PartId";
                cmd.Parameters.AddWithValue("@PartId", partId);


                con.Open();
                int numberOfRowsEffected = cmd.ExecuteNonQuery();
                con.Close();


                if (numberOfRowsEffected >= 1)
                    return true;
                else
                    return false;
            }
            catch
            {
                return false;
            }

        }
    }
}
